<template>
  <!-- single video player page start -->
<div class="flex w-full items-start justify-start gap-4 flex-col md:flex-row px-0 mt-[65px] md:px-[30px] min-h-screen">
  <div class="w-full md:w-4/6 flex flex-col gap-2 h-full md:pb-[20px]">
    <video-player></video-player>
  </div>
  <div class="w-full md:w-2/6 p-2">
    <related-content />
  </div>
</div>
<!-- single video player page end -->
</template>

<script>
import VideoPlayer from '@/components/players/VideoPlayer.vue'
import { contentStore } from '@/stores/contentStore';
import { siteStore } from '@/stores/SiteStore';
import { mapActions, mapState } from 'pinia';
import RelatedContent from '@/components/partials/RelatedContent.vue';
import { commentStore } from '@/stores/commentStore';
import { favoriteStore } from '@/stores/favoriteStore';

export default {
    name: 'PlayerView',
    components:{VideoPlayer, RelatedContent},
    methods:{
      ...mapActions(siteStore,{setHeader: 'setActiveHeader',setFooter:'setFooter'}),
      ...mapActions(contentStore, {getContent: 'getContent', getRelatedContents: 'getRelatedContents',getRatings:'getRatings'}),
      ...mapActions(commentStore,{getComment:'getComments'}),
      ...mapActions(favoriteStore, {getFavorite: 'getFavorites'})
    },
    computed:{
      ...mapState(contentStore, ['content']),
    },
    beforeRouteLeave(){
      this.setHeader(false);
    },
    created() {
      this.setHeader(true);
      this.setFooter(true);
      this.getContent(this.$route.params.id);
      this.getComment(this.$route.params.id);
      this.getFavorite(this.$route.params.id);
      this.getRatings(this.$route.params.id);
      this.getRelatedContents(this.$route.params.id);
    }
  }
</script>
