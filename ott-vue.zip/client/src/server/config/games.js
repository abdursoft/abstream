export const gamesCategory = [
  {
    en:"BINGO",
    bn:"বিঙ্গো",
    image:"casino.png",
    code:"BINGO"
  },
  {
    en:"Live Casino",
    bn:"লাইভ ক্যাসিনো",
    image:"casino.png",
    code:"LIVECASINO"
  },
  {
    en:"CASUALGAME",
    bn:"ক্যাসুয়ালগেম",
    image:"home.png",
    code:"CASUALGAME"
  },
  {
    en:"ESPORTS",
    bn:"ইস্পোর্টস",
    image:"sports.png",
    code:"ESPORTS"
  },
  {
    en:"INSTANTWIN",
    bn:"ইনস্ট্যান্টউইন",
    image:"home.png",
    code:"INSTANTWIN"
  },  {
    en:"SCRATCH CARD",
    bn:"স্ক্র্যাচ কার্ড",
    image:"home.png",
    code:"SCRATCHCARD"
  },

  {
    en:"SHOOTING",
    bn:"শুটিং",
    image:"krikbet.png",
    code:"SHOOTING"
  },
  {
    en:"SLOT",
    bn:"স্লট",
    image:"slot.png",
    code:"SLOT"
  },
  {
    en:"SPORTS",
    bn:"খেলাধুলা",
    image:"sports.png",
    code:"SPORTS"
  },
  {
    en:"TABLEGAME",
    bn:"টেবিলগেম",
    image:"table.png",
    code:"TABLEGAME"
  },
  {
    en:"VIDEOPOKER",
    bn:"ভিডিও পোকার",
    image:"home.png",
    code:"VIDEOPOKER"
  },
  {
    en:"LOTTERY",
    bn:"লটারি",
    image:"lottery.png",
    code:"LOTTERY"
  },
  {
    en:"VIRTUAL SPORTS",
    bn:"ভার্চুয়াল স্পোর্টস",
    image:"crash.png",
    code:"VIRTUAL_SPORTS"
  }
];
