<template>
  <!-- user billing section start  -->
  <div class="px-2 w-full">
    <h3 class="text-2xl">{{ $t('pageTitle.billings') }}</h3>
    <Divider />
    <DataTable :value="payments" paginator :rows="5" :rowsPerPageOptions="[5, 10, 20, 50]"
      tableStyle="min-width: 50rem">
      <Column field="payment_intent" :header="$t('table.id')"></Column>
      <Column field="amount" :header="$t('table.amount')"></Column>
      <Column field="plan.currency" :header="$t('table.currency')"></Column>
      <Column :header="$t('table.status')">
        <template #body="slot">
          <span class="px-2 py-1 border-2 rounded-md"
            :class="slot.data.status === 'success' ? 'border-green-300 text-green-400' : 'border-red-300 text-red-400'">{{
              slot.data.status }}</span>
        </template>
      </Column>
      <Column :header="$t('table.actions')">
        <template #body="slot">
          <div class="flex items-center justify-start gap-3">
            <Icon icon="iconamoon:eye-thin" width="24" height="24" class="cursor-pointer hover:text-green-400"
              @click="openDetails(slot.data.id)" />
            <Icon icon="weui:delete-on-outlined" width="24" height="24" class="cursor-pointer hover:text-red-400"
              @click="removePayment(slot.data.id)" />
          </div>
        </template>
      </Column>
    </DataTable>
  </div>
  <!-- user billing section end  -->
</template>

<script>
import { paymentStore } from '@/stores/paymentStore';
import { Icon } from '@iconify/vue';
import { mapActions, mapState } from 'pinia';

export default {
  name: "BillingPage",
  components: { Icon },
  methods: {
    ...mapActions(paymentStore, { getPayments: 'paymentList', removePayment: 'removePayment' }),
    openDetails(){},
  },
  computed: {
    ...mapState(paymentStore, ['payments', 'payment'])
  },
  created() {
    this.getPayments();
  }
}
</script>
