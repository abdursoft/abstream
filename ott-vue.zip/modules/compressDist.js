import fs from "fs";
import archiver from "archiver";
import path from "path";

export const compressDist = async () => {
    return new Promise((resolve, reject) => {
        console.log("\n🔹 Compressing dist folder...");

        const output = fs.createWriteStream(path.join(process.cwd(), "dist.zip"));
        const archive = archiver("zip", { zlib: { level: 9 } });

        output.on("close", () => {
            console.log(`✅ Compression complete: ${archive.pointer()} total bytes`);
            resolve("dist.zip");
        });

        archive.on("error", (err) => reject(err));

        archive.pipe(output);
        archive.directory("client/dist/", false);
        archive.finalize();
    });
};
