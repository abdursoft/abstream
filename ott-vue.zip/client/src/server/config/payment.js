export const payments = {
  bkash:{
    name: "Bkash",
    image: "https://pgw-integration.bkash.com/img/only-logo.78463dd4.png"
  }
}

export const amounts = [200,500,1000,5000,10000,20000]
