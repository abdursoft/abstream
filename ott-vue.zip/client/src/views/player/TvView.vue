<template>
  <!-- live tv player page start -->
  <div class="w-full px-0 mt-[65px] md:px-[30px]">
    <div class="w-full flex flex-col">
      <tv-player />
    </div>
  </div>
  <!-- live tv player page end -->
</template>

<script>
import { siteStore } from '@/stores/SiteStore';
import { mapActions, mapState } from 'pinia';
import TvPlayer from '@/components/players/TvPlayer.vue';
import { tvStore } from '@/stores/tvStore';

export default {
  name: 'TvView',
  components: { TvPlayer },
  methods: {
    ...mapActions(siteStore, { setHeader: 'setActiveHeader', setFooter:'setFooter' }),
    ...mapActions(tvStore, { getTv: 'getTv', relatedTv: 'getRelatedTv',otherTv:'getOthersTv' }),
  },
  computed: {
    ...mapState(tvStore, ['tv']),
  },
  beforeRouteLeave() {
    this.setHeader(false);
  },
  created() {
    this.setHeader(true);
    this.setFooter(true);
    this.getTv(this.$route.params.id);
    this.otherTv(this.$route.params.id);
    this.relatedTv(this.$route.params.id);
  }
}
</script>
