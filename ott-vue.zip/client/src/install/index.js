export default {
  "installed": true,
  "host": "http://127.0.0.1:8000"
};