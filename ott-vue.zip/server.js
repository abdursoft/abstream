import express from "express";
import fs from "fs";
import path from "path";
import { exec } from "child_process";
import { compressDist } from "./modules/compressDist.js";
import { fileURLToPath } from "url";

const app = express();
const PORT = 5000;
const installFilePath = path.join(process.cwd(), "client/src/install/index.js");

// Derive __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

app.use(express.urlencoded({ extended: true })); // Parse form data

// Serve an HTML form for user input
app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, 'views', 'index.html'));
});

// Handle form submission
app.post("/setup", async (req, res) => {
    const host = req.body.host;
    
    // Update the install file
    const configContent = `export default {
  "installed": true,
  "host": "${host}"
};`;
    fs.writeFileSync(installFilePath, configContent);
    console.log(`✅ Updated host in install file: ${host}`);

    // Install dependencies & build Vue project
    try {
        console.log("\n🔹 Installing dependencies...");
        exec("npm install", { cwd: "client" }, async (err) => {
            if (err) return res.send("❌ Error installing dependencies");

            console.log("\n🔹 Building Vue project...");
            exec("npm run build", { cwd: "client" }, async (err) => {
                if (err) return res.send("❌ Error building project");

                // Compress dist folder
                const zipFilePath = await compressDist();
                res.sendFile(path.join(__dirname, 'views', 'download.html'));
            });
        });
    } catch (error) {
        res.send("❌ Installation failed.");
    }
});

// Serve the zip file and remove dist folder and zip file afterward
app.get("/download", (req, res) => {
    const zipFilePath = path.join(process.cwd(), "dist.zip");

    res.download(zipFilePath, "dist.zip", (err) => {
        if (err) {
            console.error("Error downloading the file:", err);
        } else {
            // Remove the dist folder and zip file after the download is complete
            fs.rm(path.join(process.cwd(), "dist"), { recursive: true, force: true }, (err) => {
                if (err) {
                    console.error("Error removing the dist folder:", err);
                } else {
                    console.log("✅ Dist folder removed successfully.");
                }
            });

            fs.unlink(zipFilePath, (err) => {
                if (err) {
                    console.error("Error removing the dist.zip file:", err);
                } else {
                    console.log("✅ dist.zip file removed successfully.");
                }
            });
        }
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`\n🚀 Open in browser: http://localhost:${PORT}`);
});
