<template>
  <!-- breadcrumb start  -->
  <div class="w-full absolute top-0 left-0 h-[250px] bg-slate-800 flex items-center justify-center px-3">
    <div class="w-full md:w-1/2 border-dot-2 rounded-md shadow-lg bg-slate-700 flex items-center justify-center py-[20px] md:py-[40px] px-4">
      <h3 class="text-xl md:text-3xl text-white text-center font-500">{{ $t('premiumAccess') }}</h3>
    </div>
  </div>
  <!-- breadcrumb end  -->
</template>

<script>
export default{
  name: "BreadCum",
}
</script>
