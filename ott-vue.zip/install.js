import inquirer from "inquirer";
import fs from "fs";
import path from "path";
import { installDependencies } from "./modules/installDependencies.js";
import { buildVueProject } from "./modules/buildVue.js";
import { compressDist } from "./modules/compressDist.js";
import { startDownloadServer } from "./modules/downloadServer.js";

const installFilePath = path.join(process.cwd(), "client/src/install/index.js");

// Function to ask user for host input
const getUserInput = async () => {
    return await inquirer.prompt([
        {
            type: "input",
            name: "host",
            message: "Enter the host URL (e.g., https://example.com):",
            validate: (input) => input ? true : "Host cannot be empty!"
        }
    ]);
};

// Function to update install file
const updateInstallFile = async (host) => {
    const configContent = `export default {
  "installed": true,
  "host": "${host}"
};`;
    fs.writeFileSync(installFilePath, configContent);
    console.log(`✅ Updated host in install file: ${host}`);
};

// Main installation process
(async () => {
    try {
        console.log("\n🚀 Starting installation...");

        // Get user input for host
        const { host } = await getUserInput();

        // Update install file
        await updateInstallFile(host);

        // Install dependencies
        await installDependencies();

        // Build Vue project
        await buildVueProject();

        // Compress dist folder
        const zipFilePath = await compressDist();

        // Start a small server for downloading dist.zip
        await startDownloadServer(zipFilePath);

        console.log("\n✅ Installation complete! Download your build from:");
        console.log("   http://localhost:5000/download\n");

    } catch (error) {
        console.error("❌ Installation failed:", error);
    }
})();
