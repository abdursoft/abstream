<template>
  <!-- related video content start  -->
  <div class="w-full flex flex-col">
    <div class="h-[56px]">
      <div class="w-full flex items-center justify-between">
        <h3 class="font-bold">{{ $t('relatedContent') }}</h3>
        <span class="hidden flex items-center gap-2">Autoplay <ToggleSwitch v-model="checked" /></span>
      </div>
      <Divider />
    </div>
    <div class="w-full flex flex-col">
      <video-card v-for="(content, index) in sanitizeRelatedContents" :key="index" :image="content.avatar" :title="content.title" :id="content.id" :views="content.views" :slug="content.slug_title" :premium="content.premium"></video-card>
    </div>
  </div>
  <!-- related video content end  -->
</template>

<script>
import { contentStore } from '@/stores/contentStore';
import { mapActions, mapState } from 'pinia';
import VideoCard from '../cards/VideoCard.vue';
import { siteStore } from '@/stores/SiteStore';

export default{
  name: 'RelatedContent',
  components: {VideoCard},
  data(){
    return{
      checked:false
    }
  },
  methods:{
    ...mapActions(siteStore,{setAutoplay:'setAutoplay',setNextContent:'setNextContent'}),
    setPlay(){
      this.checked = this.autoPlayNext;
    },
    sayHello(){
      console.log(this.relatedContents[0])
    }
  },
  computed:{
    ...mapState(contentStore, ['relatedContents','content']),
    ...mapState(siteStore,['autoPlayNext','nextContent']),
    sanitizeRelatedContents(){
      let contentList = [];
      this.relatedContents.map((item) => {
        item.id !== this.content?.id ? contentList.push(item) : true;
      })
      return contentList;
    }
  },
  watch:{
    checked:{
      handler(value){
        this.setAutoplay(value);
        this.setNextContent(this.sayHello);
      }
    }
  },
  created(){
    this.setPlay();
  }
}
</script>
