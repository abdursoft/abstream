import { exec } from "child_process";

const runCommand = (command, description) => {
    console.log(`\n🔹 ${description}...`);
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(`❌ Error during ${description}:`, error);
                reject(error);
                return;
            }
            console.log(stdout || stderr);
            resolve();
        });
    });
};

export const buildVueProject = async () => {
    await runCommand("cd client && npm run build", "Building Vue project");
};
