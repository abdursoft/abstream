import express from "express";
import path from "path";

export const startDownloadServer = async (zipFilePath) => {
    return new Promise((resolve) => {
        const app = express();
        const PORT = 5000;

        // Serve the zip file
        app.get("/download", (req, res) => {
            res.download(path.join(process.cwd(), zipFilePath), "dist.zip", (err) => {
                if (err) {
                    console.error("❌ Error sending file:", err);
                }
            });
        });

        app.listen(PORT, () => {
            console.log(`\n🚀 Download server started at http://localhost:${PORT}/download`);
            resolve();
        });
    });
};
