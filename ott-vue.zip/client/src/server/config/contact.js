export const contacts = [
  {
    en:"24/7 support",
    bn:"২৪/৭ সাপোোর্ট",
    icon: `flat-color-icons:customer-support`,
    url:"conversation"
  },
  {
    en:"Facebook",
    bn:"ফেইসবুক",
    icon: `fluent-mdl2:facebook-logo`,
    url:"facebook"
  },
  {
    en:"Instagram",
    bn:"ইন্সাটাগ্রাম",
    icon: `f7:logo-instagram`,
    url:"instagram"
  },
  {
    en:"Telegram",
    bn:"টেলিগ্রাম",
    icon: `fa:telegram`,
    url:"telegram"
  },
];
