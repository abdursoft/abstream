<template>
  <div class="px-2 w-full">
    <h3 class="text-2xl">{{ $t('pageTitle.updates') }}</h3>
  </div>
</template>
