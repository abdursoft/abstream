<template>
  <!-- user history section start  -->
  <section class="w-full px-2">
    <h3 class="text-2xl">{{ $t('pageTitle.history') }}</h3>
    <SkeletonCard :itemLength="7" />
    <div class="w-full min-h-[440px] flex items-start justify-start flex-wrap mt-4" v-if="!isLoader">
      <div class="w-2/4 md:w-1/4 !h-[240px] px-2 my-2" v-for="(item,index) in history" :key="index" >
        <router-link class="w-full h-full" :to="{name:'watch',params:{id:item?.content.id, title:item?.content.slug_title}}">
          <div class="shadow-lg rounded-md w-full h-full relative overflow-hidden">
            <img :src="item?.content.cover" :alt="item?.content.title" class="h-full w-full">
          </div>
        </router-link>
      </div>
    </div>
  </section>
  <!-- user history section end  -->
</template>

<script>
import SkeletonCard from '@/components/skeleton/SkeletonCard.vue';
import { contentStore } from '@/stores/contentStore';
import { siteStore } from '@/stores/SiteStore';
import { mapActions, mapState } from 'pinia';

export default{
  name:"HistoryPage",
  components:{SkeletonCard},
  methods:{
    ...mapActions(contentStore,{getHistory: 'userView'})
  },
  computed:{
    ...mapState(contentStore, ['history']),
    ...mapState(siteStore,['isLoader'])
  },
  created(){
    this.getHistory();
  }
}
</script>
