import { contentGet, contentHistory, contentRating, contentRatings, contentSearch, contentView, genreContent, relatedContents } from '@/server/api/apiRoutes'
import axiosClient from '@/service/axios'
import { defineStore } from 'pinia'
import { siteStore } from './SiteStore'

export const contentStore = defineStore('contentStore', {
  state: () => {
    return {
      contents: [],
      content: null,
      history:[],
      relatedContents: [],
      ratings:null,
      site:siteStore()
    }
  },
  actions: {
    async getContent(id = '') {
      this.site.setLoader(true);
      try {
        this.content = null
        const response = await axiosClient.get(contentGet + `/${id}`)
        id === ''
          ? (this.contents = response.data.contents)
          : (this.content = response.data.contents)
        this.site.setLoader(false);
        return response
      } catch (error) {
        this.site.setLoader(false);
        return error
      }
    },
    async getRelatedContents(id) {
      this.site.setLoader(true);
      try {
        const response = await axiosClient.get(relatedContents + `/${id}`)
        this.relatedContents = response.data.contents.data
        if(this.site.autoPlayNext && this.relatedContents.length > 0){
          this.site.setNextContent(this.relatedContents[0]);
        }
        this.site.setLoader(false);
        return response
      } catch (error) {
        this.site.setLoader(false);
        return error
      }
    },
    async getContentByGenre(id) {
      this.site.setLoader(true);
      try {
        const response = await axiosClient.get(genreContent + `/${id}`)
        this.site.setLoader(false);
        return response
      } catch (error) {
        this.site.setLoader(false);
        return error
      }
    },
    async contentViews(id) {
      try {
        const response = await axiosClient.post(contentView, { id: id })
        return response
      } catch (error) {
        return error
      }
    },
    async userView() {
      this.site.setLoader(true);
      try {
        const response = await axiosClient.get(contentHistory)
        this.history = response.data.contents.data
        this.site.setLoader(false);
        return response
      } catch (error) {
        this.site.setLoader(false);
        return error
      }
    },
    async rates(data){
      this.site.setLoader(true);
      try{
        const response = await axiosClient.post(contentRating,data)
        this.site.setLoader(false);
        this.getRatings(data.content_id);
        return response
      }catch(error){
        console.log(error);
      }
    },
    async search(key,page){
      this.site.setLoader(true);
      try{
        const response = await axiosClient.get(`${contentSearch}?q=${key}&page=${page}`);
        this.site.setLoader(false);
        return response
      }catch(error){
        console.log(error);
      }
    },
    async getRatings(id){
      this.site.setLoader(true);
      try{
        const response = await axiosClient.get(contentRatings+`/${id}`);
        this.site.setLoader(false);
        this.ratings = response.data.ratings;
        return response
      }catch(error){
        console.log(error);
      }
    },
    getStyle(type){
      if(type === 'regular'){
        return 'h-[220px] md:h-[2500px] lg:h-[320px] xl:h-[360px] w-1/2 md:w-1/4 lg:w-1/6';
      }
      else if(type === 'large'){
        return 'h-[200px] md:h-[290px] lg:h-[350px] xl:h-[390px] w-1/2 md:w-1/5 lg:w-1/6';
      }
      else if(type === 'portrait'){
        return 'h-[100px] md:h-[120px] lg:h-[180px] xl:h-[200px] w-1/2 md:w-1/5';
      }else{
        return 'min-h-[220px] md:min-h-[480px] w-full';
      }
    }
  },
})
