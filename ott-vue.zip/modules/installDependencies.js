import { exec } from "child_process";
import fs from "fs/promises";

const runCommand = (command, description) => {
    console.log(`\n🔹 ${description}...`);
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                console.error(`❌ Error during ${description}:`, error);
                reject(error);
                return;
            }
            console.log(stdout || stderr);
            resolve();
        });
    });
};

export const installDependencies = async () => {
    // Install backend dependencies if node_modules is missing
    try {
        await fs.access("node_modules");
        console.log("✅ Backend dependencies already installed.");
    } catch {
        await runCommand("npm install", "Installing backend dependencies");
    }

    // Install frontend dependencies if node_modules is missing
    try {
        await fs.access("client/node_modules");
        console.log("✅ Frontend dependencies already installed.");
    } catch {
        await runCommand("cd client && npm install", "Installing frontend dependencies");
    }
};
